This is the sample data needed for some of matplotlib's examples and
docs.  See matplotlib.cbook.get_sample_data for more info.
